# Paquete para tu compañero (frontend)

Carpeta a enviar: **`recuperar-password/`** (este directorio).

1. Lee `recuperar-password/README.md`
2. Copia los JSON de `recuperar-password/json/`
3. Opcional: importa `recuperar-password/thunder-collection.json` en Thunder Client

El back ya está. Él solo reescribe `sigevaFront/src/pages/RecuperarContrasena.tsx`.
