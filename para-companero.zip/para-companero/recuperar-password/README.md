# Recuperar contraseña — contrato para el frontend

**Para:** quien conecta `sigevaFront`.  
**Back:** ya está listo en `sigevaBack`. No pidas rutas nuevas.

| | |
|---|---|
| Base local | `http://localhost:3333` |
| Front | `VITE_BASE_URL` (axios en `src/api.ts`) |
| Swagger | `http://localhost:3333/docs` → tag **Recuperación de contraseña** |
| Pantalla React | `/recuperar-contrasena` (ya existe en `App.tsx`) |
| Archivo a reescribir | `src/pages/RecuperarContrasena.tsx` |
| JSON de cada llamada | carpeta `json/` de este mismo paquete |

Un solo flujo para **Aprendiz, Funcionario, admin_sistema y Administrador**.  
El front **no** pregunta el rol. Manda el correo; el back busca en `usuarios` y en `aprendiz`.

---

## Qué está mal hoy

`RecuperarContrasena.tsx` pide **número de documento** y llama rutas que **no existen**:

- `/api/usuarios/recuperar-contrasena`
- `/api/aprendiz/recuperar-contrasena`

Además muestra toast de éxito aunque el POST falle.

**Cámbialo a 3 pasos en la misma URL** (`useState`): correo → código + nueva clave → listo.

**No toques:** `App.tsx` (la ruta ya está), `Login.tsx` (el link `?desde=` solo sirve para “Volver”), `src/api.ts`, elección, candidatos, urna, OTP de voto.

**Prohibido llamar:**

- `PUT /api/aprendiz/actualizar/contrasena` → **410**
- `/api/usuarios/recuperar-contrasena`
- `/api/aprendiz/recuperar-contrasena`

---

## APIs (las únicas de este ticket)

Sin token. Sin `x-user-id`. `Content-Type: application/json`.

| Paso | Método | Ruta | Body |
|---|---|---|---|
| 1. Pedir código | `POST` | `/api/recuperar-password/solicitar` | `{ "email" }` |
| 2. Cambiar clave | `POST` | `/api/recuperar-password/confirmar` | `{ "email", "codigo", "nueva_password" }` |

Reenviar código = volver a **solicitar**. El código anterior se invalida.

Los JSON completos (request + 200 + errores) están en `json/`.

---

## 1) Solicitar código

```
POST /api/recuperar-password/solicitar
```

**Request** (`json/01-solicitar.request.json`):

```json
{
  "email": "alexchaguendo01@gmail.com"
}
```

| Campo | Tipo | Reglas |
|---|---|---|
| `email` | string | Obligatorio, formato email. El back hace trim + minúsculas. |

No mandes `numero_documento`, `rol`, `perfil`, `jornada` ni `desde`.

**200** (`json/01-solicitar.response.200.json`):

```json
{
  "success": true,
  "message": "Código enviado al correo",
  "data": {
    "otp_generado": true,
    "email_enviado_a": "alexchaguendo01@gmail.com",
    "email_enviado": true,
    "expira_en_minutos": 5
  }
}
```

En **desarrollo** `data` trae además (producción **no**):

```json
{
  "codigo_otp_temporal": "T-RKAY",
  "_desarrollo_nota": "El código OTP se incluye solo en desarrollo. En producción, obtenerlo del email."
}
```

El usuario saca el código del correo (asunto: `Código para recuperar tu contraseña - SIGEVA`). Caduca en **5 minutos**. 6 caracteres (letras, números o guion). El back lo pasa a mayúsculas.

### Errores solicitar

| HTTP | Archivo | `codigo_error` |
|---|---|---|
| 404 | `json/01-solicitar.response.404.json` | `CUENTA_NO_ENCONTRADA` |
| 400 | `json/01-solicitar.response.400.json` | — (email inválido) |
| 500 | `json/01-solicitar.response.500.json` | `EMAIL_NO_ENVIADO` (solo producción si SMTP falla) |

Pinta `error.response.data.message`. Si es 404 de **ruta** (HTML), el Adonis viejo sigue en el 3333: hay que reiniciar el back.

Si salió 200: guarda el email, pasa al paso 2.

---

## 2) Confirmar código + nueva clave

```
POST /api/recuperar-password/confirmar
```

**Request** (`json/02-confirmar.request.json`):

```json
{
  "email": "alexchaguendo01@gmail.com",
  "codigo": "T-RKAY",
  "nueva_password": "NuevaClave2026"
}
```

| Campo | Tipo | Reglas |
|---|---|---|
| `email` | string | El **mismo** del paso 1 |
| `codigo` | string | Exactamente **6**. `trim()` + `toUpperCase()` antes de mandar |
| `nueva_password` | string | Mínimo **8**, máximo **72** |

No mandes `confirmar_password`. Ese match es solo del form.

Validación en el front **antes** del POST: código length 6, clave ≥ 8, las dos claves coinciden.

**200** (`json/02-confirmar.response.200-aprendiz.json`):

```json
{
  "success": true,
  "message": "Contraseña actualizada con éxito",
  "data": {
    "perfil": "Aprendiz",
    "login": "/api/aprendiz/login"
  }
}
```

Staff (`json/02-confirmar.response.200-funcionario.json`):

```json
{
  "success": true,
  "message": "Contraseña actualizada con éxito",
  "data": {
    "perfil": "Funcionario",
    "login": "/api/usuarios/login"
  }
}
```

`data.login` es la ruta **del API**, no la del React. Para navegar usa **`data.perfil`**:

| `data.perfil` (exacto) | `navigate` |
|---|---|
| `Aprendiz` | `/login-aprendiz` |
| `Funcionario` | `/login` |
| `admin_sistema` | `/login` |
| `Administrador` | `/login` |

**No hagas login automático.** No llames `login()` del auth. Toast de éxito + botón o redirect al login de esa tabla.

Ignora `?desde=` para este redirect. El perfil lo dice el back.

### Errores confirmar

| HTTP | Archivo | `codigo_error` |
|---|---|---|
| 400 | `json/02-confirmar.response.400-invalido.json` | `OTP_INVALIDO` |
| 400 | `json/02-confirmar.response.400-expirado.json` | `OTP_EXPIRADO` |
| 400 | `json/02-confirmar.response.400-validacion.json` | clave &lt; 8 o código ≠ 6 |
| 404 | `json/02-confirmar.response.404.json` | `CUENTA_NO_ENCONTRADA` |

Después de un 200 el código **no se reutiliza**. Segunda confirmación = `OTP_INVALIDO`.

---

## Cómo se ve (misma URL)

React: **`/recuperar-contrasena`**

Query (ya la manda `Login.tsx`):

- `?desde=aprendiz` → “Volver” a `/login-aprendiz`
- `?desde=funcionario` → “Volver” a `/login`

```
paso = "email" | "codigo" | "exito"
```

**email:** input correo, botón “Enviar código”. Sin documento, sin combo de rol, sin jornada.  
**codigo:** “Enviamos el código a {email}.” Inputs: código (6), nueva clave, repetir. Botón “Cambiar contraseña”. “Reenviar código” = solicitar otra vez. “Usar otro correo” = vuelve a email.  
**exito:** “Contraseña actualizada.” Botón “Iniciar sesión” según `perfil`.

Reutiliza `Login.css` (`login-page`, `login-card`, `login-panel`, `login-submit`, `login-error`, `login-devolver`).

---

## Axios (copiar)

`src/api.ts` ya exporta `api`. Puedes dejar esto en la página o en `src/api/recuperarPassword.ts`. **No reescribas** `src/api.ts`.

```ts
import axios from "axios";
import { api } from "../api";

export function mensajeApi(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const data = error.response?.data as { message?: string } | undefined;
    return data?.message || "No se pudo completar la solicitud";
  }
  return "No se pudo completar la solicitud";
}

export type SolicitarOk = {
  success: boolean;
  message: string;
  data: {
    otp_generado: boolean;
    email_enviado_a: string;
    email_enviado: boolean;
    expira_en_minutos: number;
    codigo_otp_temporal?: string;
  };
};

export type ConfirmarOk = {
  success: boolean;
  message: string;
  data: {
    perfil: "Aprendiz" | "Funcionario" | "admin_sistema" | "Administrador" | string;
    login: string;
  };
};

export async function solicitarRecuperacion(email: string) {
  const { data } = await api.post<SolicitarOk>("/api/recuperar-password/solicitar", {
    email,
  });
  return data;
}

export async function confirmarRecuperacion(payload: {
  email: string;
  codigo: string;
  nueva_password: string;
}) {
  const { data } = await api.post<ConfirmarOk>("/api/recuperar-password/confirmar", {
    email: payload.email,
    codigo: payload.codigo.trim().toUpperCase(),
    nueva_password: payload.nueva_password,
  });
  return data;
}

export function rutaLoginSegunPerfil(perfil: string) {
  return perfil === "Aprendiz" ? "/login-aprendiz" : "/login";
}
```

Si falla: `toast.error(mensajeApi(error))`. **Nunca** toast de éxito en el `catch`.

---

## Login después (no es de este ticket, pero para probar)

El usuario entra **a mano** en la pantalla de login con la clave nueva.

| Perfil | Método | Ruta | Body |
|---|---|---|---|
| Staff | `POST` | `/api/usuarios/login` | `json/03-login-usuarios.request.json` |
| Aprendiz | `POST` | `/api/aprendiz/login` | `json/03-login-aprendiz.request.json` |

Respuestas de ejemplo: `json/03-login-*.response.json`.

---

## Cómo probar (Network)

1. Back en **3333**. Front `npm run dev` en `sigevaFront`.
2. Login → “Recuperar contraseña” → `/recuperar-contrasena?desde=...`
3. Correo → Network **solicitar** = `{ "email" }` + **200**.
4. Código del mail (o `codigo_otp_temporal` en local) + clave 8+ + repetir → Network **confirmar** = `{ email, codigo, nueva_password }` + **200**.
5. Redirect `/login-aprendiz` o `/login` según `perfil`.
6. Entras con la **nueva** clave. La anterior falla.
7. Código inventado → **400** `OTP_INVALIDO`.
8. Correo que no existe → **404**, mensaje en pantalla. No toast de “si está registrado…”.

Thunder: importa `thunder-collection.json`.

---

## LISTO

- [ ] Ya no se pide documento. Se pide **correo**.
- [ ] Network solicitar = `POST /api/recuperar-password/solicitar` + `{ "email" }` + 200
- [ ] Network confirmar = `POST /api/recuperar-password/confirmar` + `{ email, codigo, nueva_password }` + 200
- [ ] Cero llamadas a las rutas viejas ni al PUT 410
- [ ] Sin select de rol ni jornada
- [ ] Código de 6. Clave mínimo 8. Las dos claves coinciden en el front
- [ ] Reenviar llama otra vez a solicitar
- [ ] Aprendiz → `/login-aprendiz`. Staff → `/login`
- [ ] Login con la clave nueva funciona
- [ ] 404 / 400 se ven en la UI
- [ ] Layout sigue siendo `Login.css`

---

## Si algo no cuadra

| Síntoma | Causa |
|---|---|
| 404 HTML / Cannot GET | Back viejo en 3333. Reiniciar Adonis |
| 404 JSON `CUENTA_NO_ENCONTRADA` | Ese correo no está en `usuarios` ni en `aprendiz` |
| 200 pero `email_enviado: false` | SMTP falló; en local igual viene `codigo_otp_temporal` |
| El código del mail no entra | Caducó (5 min) o no son 6 caracteres |
| Login no acepta la clave nueva | Email distinto, o login del rol contrario |

El back **no** va a crear otra ruta. Si el Network no coincide con este README, el front está llamando mal.
