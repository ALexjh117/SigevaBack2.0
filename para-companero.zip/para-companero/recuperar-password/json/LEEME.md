# Índice de JSON

Copia estos bodies tal cual. El README explica cuándo sale cada uno.

## 1. Solicitar código — `POST /api/recuperar-password/solicitar`

| Archivo | HTTP | Qué es |
|---|---|---|
| `01-solicitar.request.json` | — | Body que manda el front |
| `01-solicitar.response.200.json` | 200 | Éxito en **desarrollo** (incluye `codigo_otp_temporal`) |
| `01-solicitar.response.200-produccion.json` | 200 | Éxito en producción (sin código en el JSON) |
| `01-solicitar.response.404.json` | 404 | Correo no existe |
| `01-solicitar.response.400.json` | 400 | Email mal formado |
| `01-solicitar.response.500.json` | 500 | SMTP falló (solo producción) |

## 2. Confirmar — `POST /api/recuperar-password/confirmar`

| Archivo | HTTP | Qué es |
|---|---|---|
| `02-confirmar.request.json` | — | Body que manda el front |
| `02-confirmar.response.200-aprendiz.json` | 200 | Clave cambiada, perfil Aprendiz |
| `02-confirmar.response.200-funcionario.json` | 200 | perfil Funcionario |
| `02-confirmar.response.200-admin-sistema.json` | 200 | perfil admin_sistema |
| `02-confirmar.response.200-administrador.json` | 200 | perfil Administrador |
| `02-confirmar.response.400-invalido.json` | 400 | Código mal / ya usado |
| `02-confirmar.response.400-expirado.json` | 400 | Código de más de 5 min |
| `02-confirmar.response.400-validacion.json` | 400 | Código ≠ 6 o clave &lt; 8 |
| `02-confirmar.response.404.json` | 404 | Cuenta desapareció |
| `02-confirmar.response.410-ruta-vieja.json` | 410 | Si llamas `PUT /api/aprendiz/actualizar/contrasena` |

## 3. Login (probar la clave nueva) — no es del ticket, solo para verificar

| Archivo | Ruta |
|---|---|
| `03-login-aprendiz.request.json` | `POST /api/aprendiz/login` |
| `03-login-aprendiz.response.200.json` | 200 |
| `03-login-aprendiz.response.401.json` | 401 |
| `03-login-usuarios.request.json` | `POST /api/usuarios/login` |
| `03-login-usuarios.response.200.json` | 200 |
| `03-login-usuarios.response.401.json` | 401 |
